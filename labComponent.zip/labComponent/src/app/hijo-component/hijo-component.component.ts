import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hijo-component',
  templateUrl: './hijo-component.component.html',
  styleUrls: ['./hijo-component.component.css']
})
export class HijoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
