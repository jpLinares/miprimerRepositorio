window.onload = function() {
  //alert("window.onload");
  document.getElementById("p1").innerHTML = "Bienvenidos a mi sitio web, Nsilva";
};